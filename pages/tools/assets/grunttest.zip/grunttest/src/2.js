//@require 3

console.log('concent for 2.js')