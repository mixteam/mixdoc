//@require 2
//@require 3

console.log('concent for 1.js')