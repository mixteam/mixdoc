//@require 4

console.log('concent for 3.js')